Page({
  data:{

  },
  onLoad:function(e){
    var id = e.id;
    wx.setNavigationBarTitle({
      title: '专题详情',
    })
  }
})