Page({
  onLoad:function(){
    wx.setNavigationBarTitle({
      title: '系统设置',
    })
  }
})