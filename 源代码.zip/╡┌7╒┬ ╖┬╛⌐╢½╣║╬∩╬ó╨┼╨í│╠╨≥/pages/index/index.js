Page({
  search:function(){
    wx.navigateTo({
      url: '../search/search'
    })
  }
})