Page({
  loadCoupon:function(){
    wx.navigateTo({
      url: '../coupon/coupon'
    })
  }
})