Page({
  rank:function(){
    wx.navigateTo({
      url: '../rank/rank'
    })
  }
})